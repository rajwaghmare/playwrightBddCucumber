const {test, expect} = require('@playwright/test');

test('ArguesWest Login Function' ,async ({page})=>{


    await page.goto('https://test-cmp.aspcore.net/account/login?returnUrl=%2F');

    const pageTitle = page.title();
    console.log('Page title is :',pageTitle);

    await expect(page).toHaveTitle('CMP');
    await page.waitForTimeout(5000);

    await page.close();

})